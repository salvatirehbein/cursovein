library(ggplot2)
library(readxl)
net <- readRDS("network/net.rds")

#
# net$ldv tem que ser dividido em PC, LCV e MC ####
#

veh <- readxl::read_xlsx(path = "veh/fleet_age.xlsx", sheet = "fleet")
veh <- as.data.frame(veh)
nveh <- names(veh)
n_PC <- nveh[grep(pattern = "PC", x = nveh)]
n_LCV <- nveh[grep(pattern = "LCV", x = nveh)]
n_TRUCKS <- nveh[grep(pattern = "TRUCKS", x = nveh)]
n_BUS <- nveh[grep(pattern = "BUS", x = nveh)]
n_MC <- nveh[grep(pattern = "MC", x = nveh)]

#
# calcular proporção de cada grupo  de veiculo ####
#

PC <- net$ldv*sum(veh[, n_PC])/sum(veh[, c(n_PC, n_MC, n_LCV)])
LCV <- net$ldv*sum(veh[, n_LCV])/sum(veh[, c(n_PC, n_MC, n_LCV)])
TRUCKS <- net$hgv
BUS <- net$bus
MC <- net$ldv*sum(veh[, n_MC])/sum(veh[, c(n_PC, n_MC, n_LCV)])

# PC ####
#
# calcular proporção dentro de PC
#

kPC_G <- sum(veh$PC_G)/sum(veh[, n_PC])
kPC_FG <- sum(veh$PC_FG)/sum(veh[, n_PC])
kPC_FE <- sum(veh$PC_FE)/sum(veh[, n_PC])
kPC_E <- sum(veh$PC_E)/sum(veh[, n_PC])

cat(paste0(
  "PC_G  é ", round(kPC_G, 3), " de PC\n",
  "PC_FG é ", round(kPC_FG, 3), " de PC\n",
  "PC_FE é ", round(kPC_FE, 3), " de PC\n",
  "PC_E  é ", round(kPC_E, 3), " de PC\n",
  "sum: ", kPC_G + kPC_FG +  kPC_FE +  kPC_E, "\n"))

PC_G <- my_age(x = PC, 
               y = veh$PC_G, 
               name = "PC_G",
               k = kPC_G)
PC_FG <- my_age(x = PC, 
                y = veh$PC_FG, 
                name = "PC_FG",
                k = kPC_FG)
PC_FE <- my_age(x = PC, 
                y = veh$PC_FE,
                name = "PC_FE",
                k = kPC_FE)
PC_E <- my_age(x = PC, 
               y = veh$PC_E, 
               name = "PC_E",
               k = kPC_E)
saveRDS(PC_G, "veh/PC_G.rds")
saveRDS(PC_FG, "veh/PC_FG.rds")
saveRDS(PC_FE, "veh/PC_FE.rds")
saveRDS(PC_E, "veh/PC_E.rds")

# LCV ####
#
# calcular proporção dentro de LCV
#

kLCV_G <- sum(veh$LCV_G)/sum(veh[, n_LCV])
kLCV_FG <- sum(veh$LCV_FG)/sum(veh[, n_LCV])
kLCV_FE <- sum(veh$LCV_FE)/sum(veh[, n_LCV])
kLCV_E <- sum(veh$LCV_E)/sum(veh[, n_LCV])
kLCV_D <- sum(veh$LCV_D)/sum(veh[, n_LCV])

cat(paste0(
  "LCV_G  é ", round(kLCV_G, 3), " de LCV\n",
  "LCV_FG é ", round(kLCV_FG, 3), " de LCV\n",
  "LCV_FE é ", round(kLCV_FE, 3), " de LCV\n",
  "LCV_E  é ", round(kLCV_E, 3), " de LCV\n",
  "LCV_D  é ", round(kLCV_D, 3), " de LCV\n",
  "sum: ", kLCV_G + kLCV_FG +  kLCV_FE +  kLCV_E + kLCV_D, "\n"))

LCV_G <- my_age(x = LCV, y = veh$LCV_G, name = "LCV_G")
LCV_FG <- my_age(x = LCV, y = veh$LCV_FG, name = "LCV_FG")
LCV_FE <- my_age(x = LCV, y = veh$LCV_FE, name = "LCV_F")
LCV_E <- my_age(x = LCV, y = veh$LCV_E, name = "LCV_E")
LCV_D <- my_age(x = LCV, y = veh$LCV_D, name = "LCV_E")
saveRDS(LCV_G, "veh/LCV_G.rds")
saveRDS(LCV_FG, "veh/LCV_FG.rds")
saveRDS(LCV_FE, "veh/LCV_FE.rds")
saveRDS(LCV_E, "veh/LCV_E.rds")
saveRDS(LCV_D, "veh/LCV_E.rds")


# TRUCKS ####
#
# calcular proporção dentro de TRUCKS
#

kTRUCKS_SL <- sum(veh$TRUCKS_SL)/sum(veh[, n_TRUCKS])
kTRUCKS_L <- sum(veh$TRUCKS_L)/sum(veh[, n_TRUCKS])
kTRUCKS_M <- sum(veh$TRUCKS_M)/sum(veh[, n_TRUCKS])
kTRUCKS_SH <- sum(veh$TRUCKS_SH)/sum(veh[, n_TRUCKS])
kTRUCKS_H <- sum(veh$TRUCKS_H)/sum(veh[, n_TRUCKS])

cat(paste0(
  "TRUCKS_G  é ", round(kTRUCKS_SL, 3), " de TRUCKS\n",
  "TRUCKS_FG é ", round(kTRUCKS_L, 3), " de TRUCKS\n",
  "TRUCKS_FE é ", round(kTRUCKS_M, 3), " de TRUCKS\n",
  "TRUCKS_E  é ", round(kTRUCKS_SH, 3), " de TRUCKS\n",
  "TRUCKS_D  é ", round(kTRUCKS_H, 3), " de TRUCKS\n",
  "sum: ", kTRUCKS_SL + kTRUCKS_L +  kTRUCKS_M +  kTRUCKS_SH + kTRUCKS_H, "\n"))

TRUCKS_SL <- my_age(x = TRUCKS, y = veh$TRUCKS_SL, name = "TRUCKS_SL")
TRUCKS_L <- my_age(x = TRUCKS, y = veh$TRUCKS_L, name = "TRUCKS_L")
TRUCKS_M <- my_age(x = TRUCKS, y = veh$TRUCKS_M, name = "TRUCKS_M")
TRUCKS_SH <- my_age(x = TRUCKS, y = veh$TRUCKS_SH, name = "TRUCKS_SH")
TRUCKS_H <- my_age(x = TRUCKS, y = veh$TRUCKS_H, name = "TRUCKS_H")

saveRDS(TRUCKS_SL, "veh/TRUCKS_SL.rds")
saveRDS(TRUCKS_L, "veh/TRUCKS_SL.rds")
saveRDS(TRUCKS_M, "veh/TRUCKS_M.rds")
saveRDS(TRUCKS_SH, "veh/TRUCKS_SH.rds")
saveRDS(TRUCKS_H, "veh/TRUCKS_H.rds")


# BUS ####
#
# calcular proporção dentro de BUS
#

kBUS_URBAN <- sum(veh$BUS_URBAN)/sum(veh[, n_BUS])
kBUS_MICRO <- sum(veh$BUS_MICRO)/sum(veh[, n_BUS])
kBUS_COACH <- sum(veh$BUS_COACH)/sum(veh[, n_BUS])

cat(paste0(
  "BUS_URBAN  é ", round(kBUS_URBAN, 3), " de BUS\n",
  "BUS_MICRO  é ", round(kBUS_MICRO, 3), " de BUS\n",
  "BUS_URBAN  é ", round(kBUS_COACH, 3), " de BUS\n",
  "sum: ", kBUS_URBAN + kBUS_MICRO +  kBUS_COACH, "\n"))

BUS_URBAN <- my_age(x = BUS, y = veh$BUS_MICRO, name = "BUS_MICRO")
BUS_MICRO <- my_age(x = BUS, y = veh$BUS_MICRO, name = "BUS_MICRO")
BUS_COACH <- my_age(x = BUS, y = veh$BUS_COACH, name = "BUS_COACH")

saveRDS(BUS_URBAN, "veh/BUS_URBAN.rds")
saveRDS(BUS_MICRO, "veh/BUS_MICRO.rds")
saveRDS(BUS_COACH, "veh/BUS_COACH.rds")

# MC ####
#
# calcular proporção dentro de BUS
#

kMC_G_150 <- sum(veh$MC_G_150)/sum(veh[, n_MC])
kMC_G_150_500 <- sum(veh$MC_G_150_500)/sum(veh[, n_MC])
kMC_G_500 <- sum(veh$MC_G_500)/sum(veh[, n_MC])
kMC_FG_150 <- sum(veh$MC_FG_150)/sum(veh[, n_MC])
kMC_FG_150_500 <- sum(veh$MC_FG_150_500)/sum(veh[, n_MC])
kMC_FG_500 <- sum(veh$MC_FG_500)/sum(veh[, n_MC])
kMC_FE_150 <- sum(veh$MC_FE_150)/sum(veh[, n_MC])
kMC_FE_150_500 <- sum(veh$MC_FE_150_500)/sum(veh[, n_MC])
kMC_FE_500 <- sum(veh$MC_FE_500)/sum(veh[, n_MC])

cat(paste0(
  "MC_G_150  é ", round(kMC_G_150, 3), " de MC\n",
  "MC_G_150_500  é ", round(kMC_G_150_500, 3), " de MC\n",
  "MC_G_500  é ", round(kMC_G_500, 3), " de MC\n",
  "MC_FG_150  é ", round(kMC_FG_150, 3), " de MC\n",
  "MC_FG_150_500  é ", round(kMC_FG_150_500, 3), " de MC\n",
  "MC_FG_500  é ", round(kMC_FG_500, 3), " de MC\n",
  "MC_FE_150  é ", round(kMC_FE_150, 3), " de MC\n",
  "MC_FE_150_500  é ", round(kMC_FE_150_500, 3), " de MC\n",
  "MC_FE_500  é ", round(kMC_FE_500, 3), " de MC\n",
  "sum: ", kMC_G_150 + kMC_G_150_500 +  kMC_G_500 +
    kMC_FG_150 + kMC_FG_150_500 + kMC_FG_500 +
    kMC_FE_150 + kMC_FE_150_500 + kMC_FE_500, "\n"))

MC_G_150 <- my_age(x = MC, 
                   y = veh$MC_G_150, 
                   name = "MC_G_150", 
                   k = kMC_G_150)
MC_G_150_150 <- my_age(x = MC, 
                       y = veh$MC_G_150, 
                       name = "MC_G_150", 
                       k = kMC_G_150_500)
MC_G_150 <- my_age(x = MC, 
                   y = veh$MC_G_500, 
                   name = "MC_G_500", 
                   k = kMC_G_500)

saveRDS(BUS_URBAN, "veh/BUS_URBAN.rds")
saveRDS(BUS_MICRO, "veh/BUS_MICRO.rds")
saveRDS(BUS_COACH, "veh/BUS_COACH.rds")


# plot ####
xx <- list(
  "PC_E25"= PC_E25, #1                 
  "PC_FE25"= PC_FE25, #2                
  "PC_FE100"= PC_FE100, #3
  "PC_E100"= PC_E100, #4
  
  "LCV_E25"= LCV_E25, #5
  "LCV_FE25"= LCV_FE25,#6
  "LCV_FE100"= LCV_FE100, #7
  "LCV_E100"= LCV_E100, #8
  "LCV_B5"= LCV_B5, #9
  
  "LT_B5"= LT_B5, #10
  "SLT_B5"= SLT_B5, #11
  "MT_B5"= MT_B5, #12
  "SHT_B5"= SHT_B5, #13
  "HT_B5"= HT_B5, #14
  
  "UB_B5"= UB_B5, #15
  "MB_B5"= MB_B5, #16
  "SUB_B5"= SUB_B5, #17
  "UBSP_B5"= UBSP_B5, #18
  "AUBSP_B5"= AUBSP_B5, #19
  
  "M_E25_150"= M_E25_150, #20
  "M_E25_150_500"= M_E25_150_500, #21
  "M_E25_500"= M_E25_500, #22
  
  "M_FE25_150"= M_FE25_150, #23
  "M_FE25_150_500"= M_FE25_150_500, #24
  "M_FE25_500"= M_FE25_500, #25
  
  "M_FE100_150"= M_FE100_150, #26
  "M_FE100_150_500"= M_FE100_150_500, #27
  "M_FE100_500"= M_FE100_500) #28

df <- rbind(data.frame(veh = sapply(xx[1:4], sum)),
            data.frame(veh = sapply(xx[5:9], sum)),
            data.frame(veh = sapply(xx[10:14], sum)),
            data.frame(veh = sapply(xx[15:19], sum)),
            data.frame(veh = sapply(xx[20:28], sum)))
df$Categoria <- names(xx)
df$Categoria <- factor(df$Categoria, levels = df$Categoria)
# ggplot(df, aes(x = Categoria, y = veh))

p <- ggplot(df, aes(x = Categoria, y = veh,fill = veh), col = "white") +
  geom_bar(stat = "identity")+
  ggplot2::scale_fill_gradientn(colours = cptcity::cpt()) + 
  veinreport::theme_black() +
  theme(axis.text.x=element_text(angle=90,hjust=1))
png(filename =  paste0("images/TRAFFIC.png"),
    width = 2700, height = 1500, units = "px", pointsize = 12,
    bg = "white",  res = 300)

print(p)
dev.off()

print(sapply(xx, sum, na.rm = T))
print(sum(sapply(xx, sum, na.rm = T)[1:4])/1000000)
