# Edita para tuas necessidades
net <- sf::st_read("network/net.gpkg", crs = 31983)

cat("NOMES: ", names(net), "\n")
plot(net["ldv"], axes = T, pal = cpt(colorRampPalette = T, rev = T))
plot(net["hgv"], axes = T, pal = cpt(colorRampPalette = T, rev = T))
plot(net["bus"], axes = T, pal = cpt(colorRampPalette = T, rev = T))
saveRDS(net, 'network/net.rds')
