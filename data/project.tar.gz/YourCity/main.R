#Changing working directory
library(vein)
library(sf)
library(cptcity)
sessionInfo()

# 0 Delete previous emissions? ####
# borrar <- list.files('emi',
#                      pattern = '.rds', recursive = TRUE,
#                      full.names = TRUE)

# 1) Network ####
source("net.R")

# 2) Traffic ####
source('traffic.R') # Edit traffic.R

# 3) Estimation #### 
# Edit each input.R
# You must have all the information required in each input.R
inputs <- list.files(path = 'est', pattern = 'input.R',
                     recursive = TRUE, full.names = TRUE)
for (i in 1:length(inputs)){
  print(inputs[i])
  source(inputs[i])
}
# 4) Post-estimation #### 
g <- make_grid(net, 1000)
source('post.R')
#Changing to original working directory
print(setwd(prev))
